package com.mycompany.calculadora_missaos8;

public class CalculadoraMissaoS8 extends javax.swing.JFrame {

    public String Op, NumS, RString;
    public float Num1, Num2, RNum = 0;
    public static boolean limparTela = false;

    public CalculadoraMissaoS8() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tDisplay = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Botao0_ = new javax.swing.JButton();
        Botao1_ = new javax.swing.JButton();
        Botao2_ = new javax.swing.JButton();
        Botao3_ = new javax.swing.JButton();
        Botao4 = new javax.swing.JButton();
        Botao5_ = new javax.swing.JButton();
        Botao6_ = new javax.swing.JButton();
        Botao7_ = new javax.swing.JButton();
        Botao8_ = new javax.swing.JButton();
        Botao9_ = new javax.swing.JButton();
        BotaoPONTO_ = new javax.swing.JButton();
        BotaoSOMA_ = new javax.swing.JButton();
        BotaoSUB_ = new javax.swing.JButton();
        BotaoMUL_ = new javax.swing.JButton();
        BotaoDIV_ = new javax.swing.JButton();
        BotaoCLEAR_ = new javax.swing.JButton();
        BotaoRES_ = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        tDisplay.setFont(new java.awt.Font("Segoe UI", 0, 35)); // NOI18N
        tDisplay.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PACETECH BASIC CALCULATOR");
        jLabel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jLabel1.setMaximumSize(new java.awt.Dimension(240, 23));
        jLabel1.setMinimumSize(new java.awt.Dimension(240, 23));
        jLabel1.setName(""); // NOI18N

        Botao0_.setBackground(new java.awt.Color(102, 102, 255));
        Botao0_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao0_.setForeground(new java.awt.Color(255, 255, 255));
        Botao0_.setText("0");
        Botao0_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao0_ActionPerformed(evt);
            }
        });

        Botao1_.setBackground(new java.awt.Color(102, 102, 255));
        Botao1_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao1_.setForeground(new java.awt.Color(255, 255, 255));
        Botao1_.setText("1");
        Botao1_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao1_ActionPerformed(evt);
            }
        });

        Botao2_.setBackground(new java.awt.Color(102, 102, 255));
        Botao2_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao2_.setForeground(new java.awt.Color(255, 255, 255));
        Botao2_.setText("2");
        Botao2_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao2_ActionPerformed(evt);
            }
        });

        Botao3_.setBackground(new java.awt.Color(102, 102, 255));
        Botao3_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao3_.setForeground(new java.awt.Color(255, 255, 255));
        Botao3_.setText("3");
        Botao3_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao3_ActionPerformed(evt);
            }
        });

        Botao4.setBackground(new java.awt.Color(102, 102, 255));
        Botao4.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao4.setForeground(new java.awt.Color(255, 255, 255));
        Botao4.setText("4");
        Botao4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao4ActionPerformed(evt);
            }
        });

        Botao5_.setBackground(new java.awt.Color(102, 102, 255));
        Botao5_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao5_.setForeground(new java.awt.Color(255, 255, 255));
        Botao5_.setText("5");
        Botao5_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao5_ActionPerformed(evt);
            }
        });

        Botao6_.setBackground(new java.awt.Color(102, 102, 255));
        Botao6_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao6_.setForeground(new java.awt.Color(255, 255, 255));
        Botao6_.setText("6");
        Botao6_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao6_ActionPerformed(evt);
            }
        });

        Botao7_.setBackground(new java.awt.Color(102, 102, 255));
        Botao7_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao7_.setForeground(new java.awt.Color(255, 255, 255));
        Botao7_.setText("7");
        Botao7_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao7_ActionPerformed(evt);
            }
        });

        Botao8_.setBackground(new java.awt.Color(102, 102, 255));
        Botao8_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao8_.setForeground(new java.awt.Color(255, 255, 255));
        Botao8_.setText("8");
        Botao8_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao8_ActionPerformed(evt);
            }
        });

        Botao9_.setBackground(new java.awt.Color(102, 102, 255));
        Botao9_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        Botao9_.setForeground(new java.awt.Color(255, 255, 255));
        Botao9_.setText("9");
        Botao9_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Botao9_ActionPerformed(evt);
            }
        });

        BotaoPONTO_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoPONTO_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoPONTO_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoPONTO_.setText(".");
        BotaoPONTO_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoPONTO_ActionPerformed(evt);
            }
        });

        BotaoSOMA_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoSOMA_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoSOMA_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoSOMA_.setText("+");
        BotaoSOMA_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoSOMA_ActionPerformed(evt);
            }
        });

        BotaoSUB_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoSUB_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoSUB_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoSUB_.setText("-");
        BotaoSUB_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoSUB_ActionPerformed(evt);
            }
        });

        BotaoMUL_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoMUL_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoMUL_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoMUL_.setText("X");
        BotaoMUL_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoMUL_ActionPerformed(evt);
            }
        });

        BotaoDIV_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoDIV_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoDIV_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoDIV_.setText("/");
        BotaoDIV_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoDIV_ActionPerformed(evt);
            }
        });

        BotaoCLEAR_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoCLEAR_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoCLEAR_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoCLEAR_.setText("C");
        BotaoCLEAR_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoCLEAR_ActionPerformed(evt);
            }
        });

        BotaoRES_.setBackground(new java.awt.Color(102, 102, 255));
        BotaoRES_.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        BotaoRES_.setForeground(new java.awt.Color(255, 255, 255));
        BotaoRES_.setText("=");
        BotaoRES_.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoRES_ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(BotaoPONTO_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Botao1_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Botao4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Botao7_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Botao2_)
                                    .addComponent(Botao5_)
                                    .addComponent(Botao8_))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Botao3_)
                                    .addComponent(Botao6_)
                                    .addComponent(Botao9_))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BotaoMUL_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BotaoDIV_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BotaoSUB_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Botao0_, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(BotaoRES_, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotaoCLEAR_)
                            .addComponent(BotaoSOMA_)))
                    .addComponent(tDisplay)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Botao7_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Botao4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Botao1_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Botao8_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Botao5_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Botao2_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Botao9_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(BotaoDIV_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Botao6_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Botao3_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(BotaoSUB_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotaoRES_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(BotaoPONTO_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Botao0_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BotaoMUL_, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotaoCLEAR_, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BotaoSOMA_, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Botao0_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao0_ActionPerformed
        limpar();
        NumS = "0";
        botao();
    }//GEN-LAST:event_Botao0_ActionPerformed

    private void Botao1_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao1_ActionPerformed
        limpar();
        NumS = "1";
        botao();
    }//GEN-LAST:event_Botao1_ActionPerformed

    private void Botao2_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao2_ActionPerformed
        limpar();
        NumS = "2";
        botao();

    }//GEN-LAST:event_Botao2_ActionPerformed

    private void Botao3_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao3_ActionPerformed
        limpar();
        NumS = "3";
        botao();
    }//GEN-LAST:event_Botao3_ActionPerformed

    private void Botao4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao4ActionPerformed
        limpar();
        NumS = "4";
        botao();
    }//GEN-LAST:event_Botao4ActionPerformed

    private void Botao5_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao5_ActionPerformed
        limpar();
        NumS = "5";
        botao();
    }//GEN-LAST:event_Botao5_ActionPerformed

    private void Botao6_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao6_ActionPerformed
        limpar();
        NumS = "6";
        botao();
    }//GEN-LAST:event_Botao6_ActionPerformed

    private void Botao7_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao7_ActionPerformed
        limpar();
        NumS = "7";
        botao();
    }//GEN-LAST:event_Botao7_ActionPerformed

    private void Botao8_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao8_ActionPerformed
        limpar();
        NumS = "8";
        botao();
    }//GEN-LAST:event_Botao8_ActionPerformed

    private void Botao9_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Botao9_ActionPerformed
        limpar();
        NumS = "9";
        botao();
    }//GEN-LAST:event_Botao9_ActionPerformed

    private void BotaoPONTO_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoPONTO_ActionPerformed

        if (!(tDisplay.getText().contains(".")) && !(tDisplay.getText().isEmpty())) {
            tDisplay.setText(tDisplay.getText() + ("."));
        }
    }//GEN-LAST:event_BotaoPONTO_ActionPerformed

    private void BotaoSOMA_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoSOMA_ActionPerformed
        Num1 = Float.parseFloat(tDisplay.getText());
        Op = "+";
        tDisplay.setText("");
    }//GEN-LAST:event_BotaoSOMA_ActionPerformed

    private void BotaoSUB_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoSUB_ActionPerformed
        Num1 = Float.parseFloat(tDisplay.getText());
        Op = "-";
        tDisplay.setText("");
    }//GEN-LAST:event_BotaoSUB_ActionPerformed

    private void BotaoMUL_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoMUL_ActionPerformed
        Num1 = Float.parseFloat(tDisplay.getText());
        Op = "x";
        tDisplay.setText("");
    }//GEN-LAST:event_BotaoMUL_ActionPerformed

    private void BotaoDIV_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoDIV_ActionPerformed
        Num1 = Float.parseFloat(tDisplay.getText());
        Op = "/";
        tDisplay.setText("");
    }//GEN-LAST:event_BotaoDIV_ActionPerformed

    private void BotaoCLEAR_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoCLEAR_ActionPerformed
        tDisplay.setText("");
    }//GEN-LAST:event_BotaoCLEAR_ActionPerformed

    private void BotaoRES_ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoRES_ActionPerformed
        Num2 = Float.parseFloat(tDisplay.getText());
        operacao();
    }//GEN-LAST:event_BotaoRES_ActionPerformed

    public void botao() {
        int NumC = (tDisplay.getText()).length();

        if ((NumC <= 1) && (NumS).equals("0")) {
            tDisplay.setText(NumS);
        } else {
            tDisplay.setText(tDisplay.getText() + NumS);
        }
        limparTela = false;
    }

    public void operacao() {

        switch (Op) {

            case ("+"):
                RNum = Num1 + Num2;
                break;
            case ("-"):
                RNum = Num1 - Num2;
                break;
            case ("x"):
                RNum = Num1 * Num2;
                break;

            case ("/"):
                if (String.valueOf(Num2).equals("0")) {
                    System.out.println("Num2:" + Num2);
                    tDisplay.setText("No es posible dividir");
                } else {
                    System.out.println("Num2:" + Num2);
                    RNum = Num1 / Num2;
                }
                break;
            default:
                tDisplay.setText("Invalido:So +,-,x ou /");
                break;
        }

        RString = String.valueOf(RNum);
        limparTela = true;
        tDisplay.setText(RString);
       
    }

    public void limpar() {
        if (limparTela == true) {
            tDisplay.setText("");
           // Num1 = 0;
           // Num2 = 0;
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalculadoraMissaoS8().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Botao0_;
    private javax.swing.JButton Botao1_;
    private javax.swing.JButton Botao2_;
    private javax.swing.JButton Botao3_;
    private javax.swing.JButton Botao4;
    private javax.swing.JButton Botao5_;
    private javax.swing.JButton Botao6_;
    private javax.swing.JButton Botao7_;
    private javax.swing.JButton Botao8_;
    private javax.swing.JButton Botao9_;
    private javax.swing.JButton BotaoCLEAR_;
    private javax.swing.JButton BotaoDIV_;
    private javax.swing.JButton BotaoMUL_;
    private javax.swing.JButton BotaoPONTO_;
    private javax.swing.JButton BotaoRES_;
    private javax.swing.JButton BotaoSOMA_;
    private javax.swing.JButton BotaoSUB_;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField tDisplay;
    // End of variables declaration//GEN-END:variables
}
